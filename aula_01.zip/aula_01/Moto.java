public class Moto {
    
}
