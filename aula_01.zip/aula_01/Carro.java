public class Carro extends Auto {

    public Carro(String marca, int ano) {
        super(marca, ano);
    }
    
}
